Hi there! Welcome to my project. 

To access my code, you will have to clone this repo.
https://github.com/RoryMichelen/CS-7641/Assignment2

Part one of the assignment- training the fitness functions takes place in the 'fitness functions.ipynb' file. There should not be any tricks to running this code. Simply run the code blocks in order
All of the results from the experiments used to create visualizations were saved in csv files. This way you can run the analysis section of this notebook without having to rerun all of the experiments
The results were all saved in the results_fitness folder

Part two of the assignment- neural network training takes place in the 'nn training.ipynb' file. There should not be any tricks to running this code. Simply run the code blocks in order
All of the results from the experiments used to create visualizations were saved in csv files. This way you can run the analysis section of this notebook without having to rerun all of the experiments
The results were all saved in the results_fitness folder

You will also need to download the input data from kaggle. These files were too large for my Github repo even when compressed.
Data can be downloaded here:
https://www.kaggle.com/kemical/kickstarter-projects
after downloaded, place ks-projects-201801.csv in the same directory as the Jupyter Notebook  file 

Thank you