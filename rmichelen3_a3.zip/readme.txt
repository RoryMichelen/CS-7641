To access my code, you will have to  download rmichelen3_a3.zip from this repo:

https://github.com/RoryMichelen/CS-7641

The 'ml_assignment3.ipynb' file contains the code for all 5 parts. There should not be any tricks to running this code. Simply run the code blocks in order. 
Many of the experiment results were saved to csv files and are in the "results" folder so that you can run the analysis code blocks without having to wait for long runs to finish.

You will also need to download the input data. These files were too large for my Github repo even when compressed.

Kickstart Data can be downloaded here:
https://www.kaggle.com/kemical/kickstarter-projects
after downloaded, place ks-projects-201801.csv in the same directory as the Jupyter Notebook  file 

The spambase data is included in the 'ml_assignment3.ipynb' folder that was downloaded from github.

Thank you